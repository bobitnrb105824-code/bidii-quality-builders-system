#!/usr/bin/env python
import os
import sys
import subprocess

print("=== Setting up Bidii Quality Builders Django Project ===")

# Get the project root
project_root = "/vercel/share/v0-project"
os.chdir(project_root)

# Check if Django is installed, if not install it
try:
    import django
    print(f"Django {django.VERSION} is already installed")
except ImportError:
    print("Installing Django...")
    subprocess.run([sys.executable, "-m", "pip", "install", "django"], check=True)

# Create bidii_project directory
bidii_project_dir = os.path.join(project_root, "bidii_project")
if not os.path.exists(bidii_project_dir):
    os.makedirs(bidii_project_dir)
    print(f"Created {bidii_project_dir}")

os.chdir(bidii_project_dir)

# Create Django project if it doesn't exist
if not os.path.exists("manage.py"):
    print("Creating Django project configuration...")
    subprocess.run([sys.executable, "-m", "django", "startproject", "bidii_config", "."], check=True)
    print("Django project created!")

# Create Django app if it doesn't exist
if not os.path.exists("bidii_app"):
    print("Creating Django app...")
    subprocess.run([sys.executable, "-m", "django", "startapp", "bidii_app"], check=True)
    print("Django app created!")

print("=== Django setup complete! ===")
