#!/usr/bin/env python
import os
import sys
import django
from django.core.management import execute_from_command_line

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "bidii_project.settings")
    
    # Setup Django
    django.setup()
    
    # Run migrations silently
    from django.core.management import call_command
    try:
        call_command('migrate', verbosity=0)
        print("[v0] Database migrations completed")
    except Exception as e:
        print(f"[v0] Migration error (continuing): {e}")
    
    # Create superuser if doesn't exist
    from django.contrib.auth.models import User
    if not User.objects.filter(username='admin').exists():
        User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
        print("[v0] Created default admin user: admin / admin123")
    
    # Run development server on port 8000
    from django.core.wsgi import get_wsgi_application
    from django.core.management.commands.runserver import Command
    
    print("[v0] Starting Django development server on http://localhost:8000")
    execute_from_command_line(['manage.py', 'runserver', '0.0.0.0:8000'])
