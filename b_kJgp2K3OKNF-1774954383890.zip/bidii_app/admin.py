from django.contrib import admin
from .models import Customer, EstimateRequest, Job, Material, Invoice, Payment


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'city', 'created_date')
    search_fields = ('name', 'email', 'phone')
    list_filter = ('created_date', 'city')
    readonly_fields = ('created_date', 'updated_date')


@admin.register(EstimateRequest)
class EstimateRequestAdmin(admin.ModelAdmin):
    list_display = ('customer', 'status', 'estimated_cost', 'visit_date', 'created_date')
    search_fields = ('customer__name', 'description')
    list_filter = ('status', 'created_date', 'visit_date')
    readonly_fields = ('created_date', 'updated_date')


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ('customer', 'status', 'start_date', 'estimated_end_date', 'total_cost')
    search_fields = ('customer__name', 'description')
    list_filter = ('status', 'start_date', 'created_date')
    readonly_fields = ('created_date', 'updated_date')


@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ('name', 'job', 'quantity', 'unit', 'unit_cost')
    search_fields = ('name', 'job__customer__name')
    list_filter = ('created_date', 'unit')
    readonly_fields = ('created_date',)


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ('invoice_number', 'customer', 'status', 'total_amount', 'due_date', 'is_overdue')
    search_fields = ('invoice_number', 'customer__name')
    list_filter = ('status', 'issue_date', 'due_date')
    readonly_fields = ('issue_date', 'created_date', 'updated_date')


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'invoice', 'amount', 'payment_date', 'payment_method')
    search_fields = ('invoice__invoice_number', 'reference_number')
    list_filter = ('payment_date', 'payment_method')
    readonly_fields = ('payment_date', 'created_date')
