from django.apps import AppConfig


class BidiiAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bidii_app'
