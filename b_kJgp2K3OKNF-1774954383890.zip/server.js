#!/usr/bin/env node

const { spawn } = require('child_process');
const http = require('http');
const httpProxy = require('http-proxy');
const fs = require('fs');
const path = require('path');

console.log('[v0] Starting Django application wrapper...');

// Create a proxy server to forward requests to Django
const proxy = httpProxy.createProxyServer({
  target: 'http://localhost:8000',
  changeOrigin: true,
  ws: true
});

// Handle proxy errors
proxy.on('error', (err, req, res) => {
  console.log('[v0] Proxy error:', err.message);
  res.writeHead(503, { 'Content-Type': 'text/html' });
  res.end(`
    <html>
      <head><title>Django Server Starting</title></head>
      <body>
        <h1>Django Server is Starting...</h1>
        <p>Please wait while the application initializes.</p>
        <p>If this takes more than 30 seconds, there may be an issue.</p>
        <script>setTimeout(() => location.reload(), 2000);</script>
      </body>
    </html>
  `);
});

// Start the Django development server
const pythonProcess = spawn('python', ['run.py'], {
  stdio: 'inherit',
  env: { ...process.env, PYTHONUNBUFFERED: '1' }
});

pythonProcess.on('error', (err) => {
  console.error('[v0] Failed to start Django:', err);
  process.exit(1);
});

pythonProcess.on('close', (code) => {
  console.log('[v0] Django process exited with code', code);
  process.exit(code);
});

// Create HTTP server that proxies to Django
const server = http.createServer((req, res) => {
  proxy.web(req, res);
});

// Listen on port 3000 (which the preview will detect)
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`[v0] Proxy server listening on port ${PORT}`);
  console.log('[v0] Forwarding requests to Django on port 8000');
});

// Handle server errors
server.on('error', (err) => {
  console.error('[v0] Server error:', err);
});
