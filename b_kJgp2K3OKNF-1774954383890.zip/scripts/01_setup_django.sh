#!/bin/bash
set -e

echo "=== Setting up Bidii Quality Builders Django Project ==="

# Navigate to project root
cd /vercel/share/v0-project

# Create Django project and app
echo "Creating Django project..."
python -m django --version || pip install django

# Create project directory if it doesn't exist
mkdir -p bidii_project
cd bidii_project

# Initialize Django project
django-admin startproject bidii_config .
django-admin startapp bidii_app

echo "Django project structure created!"

# Return to root
cd /vercel/share/v0-project

echo "=== Django setup complete! ==="
