# Bidii Quality Builders - Project Management System

A comprehensive Django-based construction project management system for tracking customers, estimates, jobs, materials, invoices, and payments.

## Tech Stack

- **Backend**: Python 3, Django 4.2
- **Database**: SQLite (Development) / PostgreSQL (Production)
- **Frontend**: Django Templates, Bootstrap 5
- **Charts**: Matplotlib
- **Authentication**: Django's built-in User model

## Features

✅ **User Authentication**
- User registration and login
- Session-based authentication
- User-specific data isolation

✅ **Customer Management**
- Add, view, update, and delete customers
- Track customer contact information and address
- View all estimates, jobs, and invoices per customer

✅ **Estimate Management**
- Create and manage estimate requests
- Track visit dates and estimated costs
- Update estimate status (pending, scheduled, completed, rejected)
- Link estimates to customers

✅ **Job Scheduling**
- Create jobs from approved estimates
- Track job timeline and status
- Add materials needed for each job
- Update job progress and completion dates

✅ **Material Management**
- Add materials to jobs with quantities and costs
- Track supplier information
- Calculate material costs automatically

✅ **Invoice & Payment Tracking**
- Generate invoices from completed jobs
- Track 30-day payment deadlines
- Record payments with multiple payment methods
- Print-friendly invoice views
- Payment history and balance tracking

✅ **Dashboard**
- Key metrics: customers, jobs, completed jobs, revenue
- Matplotlib charts showing revenue trends
- Overdue invoice alerts
- Recent estimates and pending payments

## Installation & Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Initialize Database

```bash
python setup_django.py
```

This will:
- Run database migrations to create tables
- Create a superuser account (admin / admin123)

### 3. Create a Superuser (if needed)

```bash
python manage.py createsuperuser
```

### 4. Run Development Server

```bash
python manage.py runserver
```

Visit `http://localhost:8000` in your browser

## User Access

### Regular User
- **URL**: http://localhost:8000/
- **Login**: Required
- Can create and manage their own customers, estimates, jobs, invoices, and payments
- Data is isolated per user

### Admin Panel
- **URL**: http://localhost:8000/admin/
- **Login**: Superuser credentials (admin / admin123)
- Full access to all data
- Can manage users and system configuration

## Project Structure

```
bidii_project/
├── bidii_project/          # Project settings
│   ├── settings.py         # Configuration
│   ├── urls.py             # Main URLs
│   └── wsgi.py             # WSGI configuration
│
├── bidii_app/              # Main application
│   ├── models.py           # Database models
│   ├── views.py            # View logic
│   ├── forms.py            # Django forms
│   ├── urls.py             # App URLs
│   ├── admin.py            # Admin configuration
│   ├── apps.py             # App configuration
│   ├── templates/          # HTML templates
│   │   └── bidii_app/
│   │       ├── base.html
│   │       ├── login.html
│   │       ├── register.html
│   │       ├── dashboard.html
│   │       ├── customers/
│   │       ├── estimates/
│   │       ├── jobs/
│   │       ├── materials/
│   │       ├── invoices/
│   │       └── payments/
│   └── migrations/         # Database migrations
│
├── manage.py              # Django management
├── setup_django.py        # Initial setup script
├── requirements.txt       # Python dependencies
└── db.sqlite3            # SQLite database
```

## Database Models

### Customer
Stores customer information with contact details and address.

### EstimateRequest
Tracks estimate requests with visit dates and estimated costs.

### Job
Represents construction projects with timeline and budget.

### Material
Stores materials used in jobs with quantities and costs.

### Invoice
Tracks invoices issued to customers with payment terms.

### Payment
Records payments received for invoices.

## Key Features Explained

### 30-Day Payment Deadline Tracking
- Invoices automatically track a 30-day due date from issue
- Dashboard alerts show overdue invoices
- Invoice detail page displays days until due or "Overdue" status

### User Data Isolation
- Each user only sees their own customers, estimates, jobs, etc.
- Implemented using `user=request.user` on all models
- Database queries filtered by user automatically

### Revenue Charts
- Matplotlib generates monthly revenue trends
- Displayed on dashboard as base64-encoded PNG image
- Updates based on issued invoices over last 6 months

### Print-Friendly Invoices
- Invoice print view at `/invoices/<id>/print/`
- Optimized for PDF saving from browser print dialog
- Includes all payment history and balance information

## Workflow Example

1. **Customer Inquiry**: User creates a new customer record
2. **Site Visit**: User creates estimate request with visit date
3. **Quotation**: User updates estimate with estimated cost and details
4. **Approval**: User marks estimate status as "completed"
5. **Job Creation**: User creates a job from the approved estimate
6. **Materials**: User adds materials needed for the job
7. **Job Complete**: User updates job status to "completed"
8. **Invoice**: User creates invoice from completed job
9. **Payment**: User records payments as received
10. **Tracking**: Dashboard shows all metrics and alerts

## Admin Panel Features

Access at `http://localhost:8000/admin/`:
- View and manage all customers, estimates, jobs, materials, invoices, and payments
- Search and filter by status, date, customer, etc.
- Add/edit/delete records directly
- View user accounts and permissions

## Form Validation

All forms include:
- Required field validation
- Email format validation
- Numeric field validation
- Date field validation
- Password confirmation on registration

## Message Alerts

The system displays success/error messages for:
- Form submission (create, update, delete)
- Payment recording
- Status updates
- User authentication

## Production Deployment

For production deployment:

1. **Change SECRET_KEY** in `bidii_project/settings.py`
2. **Set DEBUG = False**
3. **Configure ALLOWED_HOSTS** with your domain
4. **Use PostgreSQL** instead of SQLite:
   ```python
   DATABASES = {
       'default': {
           'ENGINE': 'django.db.backends.postgresql',
           'NAME': 'bidii_db',
           'USER': 'postgres',
           'PASSWORD': 'your_password',
           'HOST': 'localhost',
           'PORT': '5432',
       }
   }
   ```
5. **Collect static files**: `python manage.py collectstatic`
6. **Use a production server** like Gunicorn or uWSGI
7. **Set up HTTPS/SSL** with reverse proxy (Nginx)
8. **Regular database backups**

## Troubleshooting

### Database Issues
```bash
python manage.py migrate
python manage.py makemigrations
```

### Clear Database and Start Fresh
```bash
rm db.sqlite3
python manage.py migrate
python setup_django.py
```

### Create Additional Superuser
```bash
python manage.py createsuperuser
```

### Debug Mode
To enable debug output, temporarily set `DEBUG = True` in settings.py

## Support & Contributing

For issues or feature requests, please create a GitHub issue or contact the development team.

## License

This project is proprietary and confidential.

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Author**: Bidii Quality Builders Development Team
