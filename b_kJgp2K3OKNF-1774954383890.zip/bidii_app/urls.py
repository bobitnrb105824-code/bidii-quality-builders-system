from django.urls import path
from . import views

urlpatterns = [
    # Auth URLs
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Customer URLs
    path('customers/', views.customer_list, name='customer_list'),
    path('customers/<int:pk>/', views.customer_detail, name='customer_detail'),
    path('customers/new/', views.customer_create, name='customer_create'),
    path('customers/<int:pk>/edit/', views.customer_update, name='customer_update'),
    path('customers/<int:pk>/delete/', views.customer_delete, name='customer_delete'),
    
    # Estimate URLs
    path('estimates/', views.estimate_list, name='estimate_list'),
    path('estimates/<int:pk>/', views.estimate_detail, name='estimate_detail'),
    path('estimates/new/', views.estimate_create, name='estimate_create'),
    path('estimates/<int:pk>/edit/', views.estimate_update, name='estimate_update'),
    path('estimates/<int:pk>/status/', views.estimate_update_status, name='estimate_update_status'),
    path('estimates/<int:pk>/delete/', views.estimate_delete, name='estimate_delete'),
    
    # Job URLs
    path('jobs/', views.job_list, name='job_list'),
    path('jobs/<int:pk>/', views.job_detail, name='job_detail'),
    path('jobs/new/', views.job_create, name='job_create'),
    path('jobs/<int:pk>/edit/', views.job_update, name='job_update'),
    path('jobs/<int:pk>/status/', views.job_update_status, name='job_update_status'),
    path('jobs/<int:pk>/delete/', views.job_delete, name='job_delete'),
    
    # Material URLs
    path('jobs/<int:job_pk>/materials/new/', views.material_create, name='material_create'),
    path('materials/<int:pk>/edit/', views.material_update, name='material_update'),
    path('materials/<int:pk>/delete/', views.material_delete, name='material_delete'),
    
    # Invoice URLs
    path('invoices/', views.invoice_list, name='invoice_list'),
    path('invoices/<int:pk>/', views.invoice_detail, name='invoice_detail'),
    path('invoices/new/', views.invoice_create, name='invoice_create'),
    path('invoices/<int:pk>/edit/', views.invoice_update, name='invoice_update'),
    path('invoices/<int:pk>/status/', views.invoice_update_status, name='invoice_update_status'),
    path('invoices/<int:pk>/delete/', views.invoice_delete, name='invoice_delete'),
    path('invoices/<int:pk>/print/', views.invoice_print, name='invoice_print'),
    
    # Payment URLs
    path('invoices/<int:invoice_pk>/payments/new/', views.payment_create, name='payment_create'),
]
