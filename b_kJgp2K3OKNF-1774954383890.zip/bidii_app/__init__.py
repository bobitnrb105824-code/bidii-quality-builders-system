# Django app initialization
