from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import timedelta
import matplotlib.pyplot as plt
import matplotlib
import io
import base64
from urllib.parse import urlencode

from .models import Customer, EstimateRequest, Job, Material, Invoice, Payment
from .forms import (
    CustomerForm, EstimateRequestForm, EstimateStatusForm, JobForm, JobStatusForm,
    MaterialForm, InvoiceForm, InvoiceStatusForm, PaymentForm, LoginForm, RegisterForm
)

# Set matplotlib to use non-interactive backend
matplotlib.use('Agg')


def login_view(request):
    """Handle user login."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    
    return render(request, 'bidii_app/login.html', {'form': form})


def register_view(request):
    """Handle user registration."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name'],
                password=form.cleaned_data['password']
            )
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    
    return render(request, 'bidii_app/register.html', {'form': form})


def logout_view(request):
    """Handle user logout."""
    logout(request)
    return redirect('login')


def generate_chart():
    """Generate a matplotlib chart showing revenue trends."""
    # Get invoices from the last 6 months
    six_months_ago = timezone.now().date() - timedelta(days=180)
    invoices = Invoice.objects.filter(issue_date__gte=six_months_ago).order_by('issue_date')
    
    # Group by month and sum amounts
    from collections import defaultdict
    monthly_revenue = defaultdict(float)
    
    for invoice in invoices:
        month_key = invoice.issue_date.strftime('%Y-%m')
        monthly_revenue[month_key] += float(invoice.total_amount)
    
    if not monthly_revenue:
        # Return empty chart if no data
        months = []
        amounts = []
    else:
        months = sorted(monthly_revenue.keys())
        amounts = [monthly_revenue[m] for m in months]
    
    # Create figure
    fig, ax = plt.subplots(figsize=(10, 5))
    
    if months:
        ax.bar(months, amounts, color='#4CAF50', alpha=0.8)
    
    ax.set_xlabel('Month', fontsize=10)
    ax.set_ylabel('Revenue ($)', fontsize=10)
    ax.set_title('Monthly Revenue Trend', fontsize=12, fontweight='bold')
    ax.grid(axis='y', alpha=0.3)
    
    # Rotate x-axis labels
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    # Convert to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=100)
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return image_base64


@login_required(login_url='login')
def dashboard(request):
    """Display dashboard with key metrics."""
    user = request.user
    
    # Get user's data
    total_customers = Customer.objects.filter(user=user).count()
    total_jobs = Job.objects.filter(user=user).count()
    completed_jobs = Job.objects.filter(user=user, status='completed').count()
    pending_jobs = Job.objects.filter(user=user, status__in=['pending', 'in_progress']).count()
    
    # Calculate revenue
    total_revenue = Invoice.objects.filter(user=user).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    # Get pending invoices and payments
    pending_invoices = Invoice.objects.filter(user=user, status__in=['issued', 'overdue'])
    overdue_invoices = pending_invoices.filter(status='overdue')
    total_pending = pending_invoices.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    # Get recent estimates
    recent_estimates = EstimateRequest.objects.filter(user=user)[:5]
    
    # Generate chart
    chart_image = generate_chart()
    
    context = {
        'total_customers': total_customers,
        'total_jobs': total_jobs,
        'completed_jobs': completed_jobs,
        'pending_jobs': pending_jobs,
        'total_revenue': float(total_revenue),
        'total_pending': float(total_pending),
        'overdue_count': overdue_invoices.count(),
        'pending_invoices': pending_invoices[:10],
        'recent_estimates': recent_estimates,
        'chart_image': chart_image,
    }
    
    return render(request, 'bidii_app/dashboard.html', context)


# ==================== CUSTOMER VIEWS ====================

@login_required(login_url='login')
def customer_list(request):
    """Display list of customers."""
    customers = Customer.objects.filter(user=request.user)
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        customers = customers.filter(
            Q(name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone__icontains=search_query)
        )
    
    context = {
        'customers': customers,
        'search_query': search_query,
    }
    return render(request, 'bidii_app/customers/list.html', context)


@login_required(login_url='login')
def customer_detail(request, pk):
    """Display customer details."""
    customer = get_object_or_404(Customer, pk=pk, user=request.user)
    estimates = EstimateRequest.objects.filter(customer=customer)
    jobs = Job.objects.filter(customer=customer)
    invoices = Invoice.objects.filter(customer=customer)
    
    context = {
        'customer': customer,
        'estimates': estimates,
        'jobs': jobs,
        'invoices': invoices,
    }
    return render(request, 'bidii_app/customers/detail.html', context)


@login_required(login_url='login')
def customer_create(request):
    """Create a new customer."""
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save(commit=False)
            customer.user = request.user
            customer.save()
            messages.success(request, 'Customer created successfully!')
            return redirect('customer_detail', pk=customer.pk)
    else:
        form = CustomerForm()
    
    return render(request, 'bidii_app/customers/form.html', {'form': form, 'title': 'Add Customer'})


@login_required(login_url='login')
def customer_update(request, pk):
    """Update an existing customer."""
    customer = get_object_or_404(Customer, pk=pk, user=request.user)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Customer updated successfully!')
            return redirect('customer_detail', pk=customer.pk)
    else:
        form = CustomerForm(instance=customer)
    
    return render(request, 'bidii_app/customers/form.html', {'form': form, 'title': 'Edit Customer'})


@login_required(login_url='login')
def customer_delete(request, pk):
    """Delete a customer."""
    customer = get_object_or_404(Customer, pk=pk, user=request.user)
    if request.method == 'POST':
        customer.delete()
        messages.success(request, 'Customer deleted successfully!')
        return redirect('customer_list')
    
    return render(request, 'bidii_app/customers/delete_confirm.html', {'customer': customer})


# ==================== ESTIMATE VIEWS ====================

@login_required(login_url='login')
def estimate_list(request):
    """Display list of estimates."""
    estimates = EstimateRequest.objects.filter(user=request.user)
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        estimates = estimates.filter(status=status_filter)
    
    context = {
        'estimates': estimates,
        'status_filter': status_filter,
    }
    return render(request, 'bidii_app/estimates/list.html', context)


@login_required(login_url='login')
def estimate_detail(request, pk):
    """Display estimate details."""
    estimate = get_object_or_404(EstimateRequest, pk=pk, user=request.user)
    context = {'estimate': estimate}
    return render(request, 'bidii_app/estimates/detail.html', context)


@login_required(login_url='login')
def estimate_create(request):
    """Create a new estimate."""
    if request.method == 'POST':
        form = EstimateRequestForm(request.POST)
        if form.is_valid():
            estimate = form.save(commit=False)
            estimate.user = request.user
            estimate.save()
            messages.success(request, 'Estimate created successfully!')
            return redirect('estimate_detail', pk=estimate.pk)
    else:
        form = EstimateRequestForm()
        form.fields['customer'].queryset = Customer.objects.filter(user=request.user)
    
    return render(request, 'bidii_app/estimates/form.html', {'form': form, 'title': 'Create Estimate'})


@login_required(login_url='login')
def estimate_update(request, pk):
    """Update an estimate."""
    estimate = get_object_or_404(EstimateRequest, pk=pk, user=request.user)
    if request.method == 'POST':
        form = EstimateRequestForm(request.POST, instance=estimate)
        if form.is_valid():
            form.save()
            messages.success(request, 'Estimate updated successfully!')
            return redirect('estimate_detail', pk=estimate.pk)
    else:
        form = EstimateRequestForm(instance=estimate)
        form.fields['customer'].queryset = Customer.objects.filter(user=request.user)
    
    return render(request, 'bidii_app/estimates/form.html', {'form': form, 'title': 'Edit Estimate'})


@login_required(login_url='login')
def estimate_update_status(request, pk):
    """Update estimate status."""
    estimate = get_object_or_404(EstimateRequest, pk=pk, user=request.user)
    if request.method == 'POST':
        form = EstimateStatusForm(request.POST, instance=estimate)
        if form.is_valid():
            form.save()
            messages.success(request, 'Estimate status updated!')
            return redirect('estimate_detail', pk=estimate.pk)
    else:
        form = EstimateStatusForm(instance=estimate)
    
    return render(request, 'bidii_app/estimates/update_status.html', {'form': form, 'estimate': estimate})


@login_required(login_url='login')
def estimate_delete(request, pk):
    """Delete an estimate."""
    estimate = get_object_or_404(EstimateRequest, pk=pk, user=request.user)
    if request.method == 'POST':
        estimate.delete()
        messages.success(request, 'Estimate deleted!')
        return redirect('estimate_list')
    
    return render(request, 'bidii_app/estimates/delete_confirm.html', {'estimate': estimate})


# ==================== JOB VIEWS ====================

@login_required(login_url='login')
def job_list(request):
    """Display list of jobs."""
    jobs = Job.objects.filter(user=request.user)
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        jobs = jobs.filter(status=status_filter)
    
    context = {
        'jobs': jobs,
        'status_filter': status_filter,
    }
    return render(request, 'bidii_app/jobs/list.html', context)


@login_required(login_url='login')
def job_detail(request, pk):
    """Display job details."""
    job = get_object_or_404(Job, pk=pk, user=request.user)
    materials = Material.objects.filter(job=job)
    invoices = Invoice.objects.filter(job=job)
    
    context = {
        'job': job,
        'materials': materials,
        'invoices': invoices,
    }
    return render(request, 'bidii_app/jobs/detail.html', context)


@login_required(login_url='login')
def job_create(request):
    """Create a new job."""
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.user = request.user
            job.save()
            messages.success(request, 'Job created successfully!')
            return redirect('job_detail', pk=job.pk)
    else:
        form = JobForm()
        form.fields['customer'].queryset = Customer.objects.filter(user=request.user)
        form.fields['estimate'].queryset = EstimateRequest.objects.filter(user=request.user, status='completed')
    
    return render(request, 'bidii_app/jobs/form.html', {'form': form, 'title': 'Create Job'})


@login_required(login_url='login')
def job_update(request, pk):
    """Update a job."""
    job = get_object_or_404(Job, pk=pk, user=request.user)
    if request.method == 'POST':
        form = JobForm(request.POST, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, 'Job updated successfully!')
            return redirect('job_detail', pk=job.pk)
    else:
        form = JobForm(instance=job)
        form.fields['customer'].queryset = Customer.objects.filter(user=request.user)
        form.fields['estimate'].queryset = EstimateRequest.objects.filter(user=request.user)
    
    return render(request, 'bidii_app/jobs/form.html', {'form': form, 'title': 'Edit Job'})


@login_required(login_url='login')
def job_update_status(request, pk):
    """Update job status."""
    job = get_object_or_404(Job, pk=pk, user=request.user)
    if request.method == 'POST':
        form = JobStatusForm(request.POST, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, 'Job status updated!')
            return redirect('job_detail', pk=job.pk)
    else:
        form = JobStatusForm(instance=job)
    
    return render(request, 'bidii_app/jobs/update_status.html', {'form': form, 'job': job})


@login_required(login_url='login')
def job_delete(request, pk):
    """Delete a job."""
    job = get_object_or_404(Job, pk=pk, user=request.user)
    if request.method == 'POST':
        job.delete()
        messages.success(request, 'Job deleted!')
        return redirect('job_list')
    
    return render(request, 'bidii_app/jobs/delete_confirm.html', {'job': job})


# ==================== MATERIAL VIEWS ====================

@login_required(login_url='login')
def material_create(request, job_pk):
    """Create a material for a job."""
    job = get_object_or_404(Job, pk=job_pk, user=request.user)
    if request.method == 'POST':
        form = MaterialForm(request.POST)
        if form.is_valid():
            material = form.save(commit=False)
            material.user = request.user
            material.job = job
            material.save()
            messages.success(request, 'Material added!')
            return redirect('job_detail', pk=job.pk)
    else:
        form = MaterialForm()
    
    return render(request, 'bidii_app/materials/form.html', {'form': form, 'job': job, 'title': 'Add Material'})


@login_required(login_url='login')
def material_update(request, pk):
    """Update a material."""
    material = get_object_or_404(Material, pk=pk, user=request.user)
    if request.method == 'POST':
        form = MaterialForm(request.POST, instance=material)
        if form.is_valid():
            form.save()
            messages.success(request, 'Material updated!')
            return redirect('job_detail', pk=material.job.pk)
    else:
        form = MaterialForm(instance=material)
    
    return render(request, 'bidii_app/materials/form.html', {'form': form, 'material': material, 'title': 'Edit Material'})


@login_required(login_url='login')
def material_delete(request, pk):
    """Delete a material."""
    material = get_object_or_404(Material, pk=pk, user=request.user)
    job_pk = material.job.pk
    if request.method == 'POST':
        material.delete()
        messages.success(request, 'Material deleted!')
        return redirect('job_detail', pk=job_pk)
    
    return render(request, 'bidii_app/materials/delete_confirm.html', {'material': material})


# ==================== INVOICE VIEWS ====================

@login_required(login_url='login')
def invoice_list(request):
    """Display list of invoices."""
    invoices = Invoice.objects.filter(user=request.user)
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        invoices = invoices.filter(status=status_filter)
    
    context = {
        'invoices': invoices,
        'status_filter': status_filter,
    }
    return render(request, 'bidii_app/invoices/list.html', context)


@login_required(login_url='login')
def invoice_detail(request, pk):
    """Display invoice details."""
    invoice = get_object_or_404(Invoice, pk=pk, user=request.user)
    payments = Payment.objects.filter(invoice=invoice)
    
    total_paid = payments.aggregate(Sum('amount'))['amount__sum'] or 0
    remaining = invoice.total_amount - total_paid
    
    context = {
        'invoice': invoice,
        'payments': payments,
        'total_paid': float(total_paid),
        'remaining': float(remaining),
    }
    return render(request, 'bidii_app/invoices/detail.html', context)


@login_required(login_url='login')
def invoice_create(request):
    """Create a new invoice."""
    if request.method == 'POST':
        form = InvoiceForm(request.POST)
        if form.is_valid():
            invoice = form.save(commit=False)
            invoice.user = request.user
            invoice.save()
            messages.success(request, 'Invoice created successfully!')
            return redirect('invoice_detail', pk=invoice.pk)
    else:
        form = InvoiceForm()
        form.fields['customer'].queryset = Customer.objects.filter(user=request.user)
        form.fields['job'].queryset = Job.objects.filter(user=request.user, status='completed')
    
    return render(request, 'bidii_app/invoices/form.html', {'form': form, 'title': 'Create Invoice'})


@login_required(login_url='login')
def invoice_update(request, pk):
    """Update an invoice."""
    invoice = get_object_or_404(Invoice, pk=pk, user=request.user)
    if request.method == 'POST':
        form = InvoiceForm(request.POST, instance=invoice)
        if form.is_valid():
            form.save()
            messages.success(request, 'Invoice updated!')
            return redirect('invoice_detail', pk=invoice.pk)
    else:
        form = InvoiceForm(instance=invoice)
        form.fields['customer'].queryset = Customer.objects.filter(user=request.user)
        form.fields['job'].queryset = Job.objects.filter(user=request.user)
    
    return render(request, 'bidii_app/invoices/form.html', {'form': form, 'title': 'Edit Invoice'})


@login_required(login_url='login')
def invoice_update_status(request, pk):
    """Update invoice status."""
    invoice = get_object_or_404(Invoice, pk=pk, user=request.user)
    if request.method == 'POST':
        form = InvoiceStatusForm(request.POST, instance=invoice)
        if form.is_valid():
            form.save()
            messages.success(request, 'Invoice status updated!')
            return redirect('invoice_detail', pk=invoice.pk)
    else:
        form = InvoiceStatusForm(instance=invoice)
    
    return render(request, 'bidii_app/invoices/update_status.html', {'form': form, 'invoice': invoice})


@login_required(login_url='login')
def invoice_delete(request, pk):
    """Delete an invoice."""
    invoice = get_object_or_404(Invoice, pk=pk, user=request.user)
    if request.method == 'POST':
        invoice.delete()
        messages.success(request, 'Invoice deleted!')
        return redirect('invoice_list')
    
    return render(request, 'bidii_app/invoices/delete_confirm.html', {'invoice': invoice})


@login_required(login_url='login')
def invoice_print(request, pk):
    """Print-friendly invoice view."""
    invoice = get_object_or_404(Invoice, pk=pk, user=request.user)
    payments = Payment.objects.filter(invoice=invoice)
    
    total_paid = payments.aggregate(Sum('amount'))['amount__sum'] or 0
    remaining = invoice.total_amount - total_paid
    
    context = {
        'invoice': invoice,
        'payments': payments,
        'total_paid': float(total_paid),
        'remaining': float(remaining),
    }
    return render(request, 'bidii_app/invoices/print.html', context)


# ==================== PAYMENT VIEWS ====================

@login_required(login_url='login')
def payment_create(request, invoice_pk):
    """Create a payment for an invoice."""
    invoice = get_object_or_404(Invoice, pk=invoice_pk, user=request.user)
    
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.user = request.user
            payment.invoice = invoice
            payment.save()
            
            # Update invoice status if fully paid
            total_paid = Payment.objects.filter(invoice=invoice).aggregate(Sum('amount'))['amount__sum'] or 0
            if total_paid >= invoice.total_amount:
                invoice.status = 'paid'
                invoice.save()
                messages.success(request, 'Invoice marked as paid!')
            else:
                messages.success(request, 'Payment recorded!')
            
            return redirect('invoice_detail', pk=invoice.pk)
    else:
        form = PaymentForm()
    
    return render(request, 'bidii_app/payments/form.html', {'form': form, 'invoice': invoice, 'title': 'Record Payment'})
