#!/usr/bin/env python
"""
Django setup script to initialize database and create superuser
Run this once after initial setup: python setup_django.py
"""

import os
import sys
import django
from django.conf import settings
from django.core.management import execute_from_command_line
from django.contrib.auth.models import User

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bidii_project.settings')
django.setup()

print("=" * 50)
print("Bidii Quality Builders - Django Setup")
print("=" * 50)

# Run migrations
print("\n[1/2] Running database migrations...")
execute_from_command_line(['manage.py', 'migrate'])

# Create superuser
print("\n[2/2] Creating superuser account...")
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@bidii.com', 'admin123')
    print("✓ Superuser created: username='admin', password='admin123'")
    print("  (Change password after first login)")
else:
    print("✓ Superuser 'admin' already exists")

print("\n" + "=" * 50)
print("Setup complete!")
print("=" * 50)
print("\nNext steps:")
print("1. Run the development server: python manage.py runserver")
print("2. Visit http://localhost:8000 in your browser")
print("3. Admin panel: http://localhost:8000/admin/")
print("=" * 50)
